package com.botviper.dashboard

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Client for the real PYLON Panel server (server/index.js, auth.js, bots.js).
 * This talks directly to the Node.js process running on Termux - every call
 * here does something real: start/stop/kill actually spawn/kill the bot's
 * child process via runner.js, independent of the bot itself (so it works
 * even when the bot has crashed or was never started).
 *
 * Stats fields (cpuPercent, ramUsedMb, ramLimitMb, uptimeSec) and the
 * command endpoint are read/sent defensively: if the panel backend doesn't
 * expose them yet, calls simply come back empty/failed instead of crashing
 * the app. See SERVER_API_NOTES.md for the exact routes the app expects.
 */
class PylonApi(private val panelUrl: String) {

    private val client = OkHttpClient.Builder()
        // Termux can be slow to answer right after the panel starts (Node cold
        // start, phone Wi-Fi power-saving, etc.) - give it more room than the
        // old 10s/15s before treating it as unreachable, and retry once on a
        // dropped connection instead of failing the whole call immediately.
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val jsonMedia = "application/json".toMediaType()

    private fun authed(path: String, token: String): Request.Builder {
        return Request.Builder()
            .url("$panelUrl$path")
            .addHeader("Authorization", "Bearer $token")
            .addHeader("Accept", "application/json")
    }

    /** POST /api/auth/login -> { token, username } */
    fun login(username: String, password: String, onResult: (Result<LoginInfo>) -> Unit) {
        val body = JSONObject().apply {
            put("username", username)
            put("password", password)
        }.toString()

        val req = Request.Builder()
            .url("$panelUrl/api/auth/login")
            .post(body.toRequestBody(jsonMedia))
            .build()

        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = onResult(Result.failure(e))
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        val msg = runCatching { JSONObject(it.body?.string().orEmpty()).optString("error") }.getOrNull()
                        onResult(Result.failure(IOException(msg ?: "HTTP ${it.code}")))
                        return
                    }
                    try {
                        val json = JSONObject(it.body?.string().orEmpty())
                        onResult(Result.success(LoginInfo(json.getString("token"), json.getString("username"))))
                    } catch (e: Exception) {
                        onResult(Result.failure(e))
                    }
                }
            }
        })
    }

    /** GET /api/bots -> list of bots this user owns on the panel. */
    fun getBots(token: String, onResult: (Result<List<BotInfo>>) -> Unit) {
        val req = authed("/api/bots", token).get().build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = onResult(Result.failure(e))
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        onResult(Result.failure(IOException("HTTP ${it.code}")))
                        return
                    }
                    try {
                        val arr = JSONArray(it.body?.string().orEmpty())
                        val list = mutableListOf<BotInfo>()
                        for (i in 0 until arr.length()) {
                            list.add(parseBotInfo(arr.getJSONObject(i)))
                        }
                        onResult(Result.success(list))
                    } catch (e: Exception) {
                        onResult(Result.failure(e))
                    }
                }
            }
        })
    }

    /** GET /api/bots/{id} -> single bot detail, used to refresh stats without pulling the whole list. */
    fun getBot(token: String, botId: String, onResult: (Result<BotInfo>) -> Unit) {
        val req = authed("/api/bots/$botId", token).get().build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = onResult(Result.failure(e))
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        onResult(Result.failure(IOException("HTTP ${it.code}")))
                        return
                    }
                    try {
                        onResult(Result.success(parseBotInfo(JSONObject(it.body?.string().orEmpty()))))
                    } catch (e: Exception) {
                        onResult(Result.failure(e))
                    }
                }
            }
        })
    }

    private fun parseBotInfo(b: JSONObject): BotInfo {
        return BotInfo(
            id = b.getString("id"),
            name = b.getString("name"),
            runtime = b.optString("runtime"),
            status = b.optString("status"),
            ramMb = b.optInt("ramMb"),
            cpuPercent = if (b.has("cpuPercent")) b.optDouble("cpuPercent", -1.0) else -1.0,
            ramUsedMb = if (b.has("ramUsedMb")) b.optInt("ramUsedMb", -1) else -1,
            ramLimitMb = if (b.has("ramLimitMb")) b.optInt("ramLimitMb", -1) else -1,
            uptimeSec = if (b.has("uptimeSec")) b.optLong("uptimeSec", -1L) else -1L
        )
    }

    /** POST /api/bots/{id}/start | stop | restart | kill */
    fun power(token: String, botId: String, action: String, onResult: (Result<String>) -> Unit) {
        val req = authed("/api/bots/$botId/$action", token)
            .post("".toRequestBody(null))
            .build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = onResult(Result.failure(e))
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        val msg = runCatching { JSONObject(it.body?.string().orEmpty()).optString("error") }.getOrNull()
                        onResult(Result.failure(IOException(msg ?: "HTTP ${it.code}")))
                        return
                    }
                    val status = runCatching { JSONObject(it.body?.string().orEmpty()).optString("status") }.getOrNull()
                    onResult(Result.success(status ?: action))
                }
            }
        })
    }

    /** POST /api/bots/{id}/command  { "command": "..." } — sends a line to the bot's stdin, like a real console. */
    fun sendCommand(token: String, botId: String, command: String, onResult: (Result<Unit>) -> Unit) {
        val body = JSONObject().put("command", command).toString()
        val req = authed("/api/bots/$botId/command", token)
            .post(body.toRequestBody(jsonMedia))
            .build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = onResult(Result.failure(e))
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        val msg = runCatching { JSONObject(it.body?.string().orEmpty()).optString("error") }.getOrNull()
                        onResult(Result.failure(IOException(msg ?: "HTTP ${it.code}")))
                        return
                    }
                    onResult(Result.success(Unit))
                }
            }
        })
    }

    /** GET /api/bots/{id}/logs -> snapshot of recent log lines (tail). */
    fun getLogsSnapshot(token: String, botId: String, onResult: (Result<String>) -> Unit) {
        val req = authed("/api/bots/$botId/logs", token).get().build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = onResult(Result.failure(e))
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        onResult(Result.failure(IOException("HTTP ${it.code}")))
                        return
                    }
                    val logs = runCatching { JSONObject(it.body?.string().orEmpty()).optString("logs") }.getOrDefault("")
                    onResult(Result.success(logs))
                }
            }
        })
    }

    /** Build the real ws:// (or wss://) URL for live log tailing (server/ws.js, path /ws/logs). */
    fun buildLogsSocketUrl(token: String, botId: String): String {
        val wsBase = when {
            panelUrl.startsWith("https://") -> "wss://" + panelUrl.removePrefix("https://")
            panelUrl.startsWith("http://") -> "ws://" + panelUrl.removePrefix("http://")
            else -> "ws://$panelUrl"
        }
        return "$wsBase/ws/logs?token=$token&botId=$botId"
    }

    data class LoginInfo(val token: String, val username: String)

    data class BotInfo(
        val id: String,
        val name: String,
        val runtime: String,
        val status: String,
        val ramMb: Int,
        // Optional live-stat fields. -1 (or -1.0) means "panel didn't send this field".
        val cpuPercent: Double = -1.0,
        val ramUsedMb: Int = -1,
        val ramLimitMb: Int = -1,
        val uptimeSec: Long = -1L
    )
}

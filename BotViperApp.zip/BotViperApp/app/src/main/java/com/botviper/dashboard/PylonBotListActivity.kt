package com.botviper.dashboard

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.textfield.TextInputEditText

/**
 * Bot list ("Bot của bạn"): pulls the real list from /api/bots, lets the
 * user search/filter it client-side, and keeps it fresh with a light
 * auto-refresh poll while the screen is visible — the same feel as
 * Pterodactyl's server list auto-updating status dots.
 */
class PylonBotListActivity : AppCompatActivity() {

    private lateinit var api: PylonApi
    private lateinit var token: String
    private lateinit var adapter: BotListAdapter

    private val mainHandler = Handler(Looper.getMainLooper())
    private var autoRefreshActive = false
    private var currentQuery = ""
    private var allBots: List<PylonApi.BotInfo> = emptyList()

    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyText: TextView
    private lateinit var errorState: View
    private lateinit var errorStateText: TextView

    private val autoRefreshRunnable = object : Runnable {
        override fun run() {
            if (!autoRefreshActive) return
            load(showSpinner = false)
            mainHandler.postDelayed(this, 8000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pylon_bot_list)

        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val panelUrl = prefs.getString(Prefs.PYLON_PANEL_URL, null)
        val savedToken = prefs.getString(Prefs.PYLON_TOKEN, null)

        if (panelUrl.isNullOrBlank() || savedToken.isNullOrBlank()) {
            startActivity(Intent(this, PylonLoginActivity::class.java))
            finish()
            return
        }
        api = PylonApi(panelUrl)
        token = savedToken

        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        val recycler = findViewById<RecyclerView>(R.id.botListView)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = BotListAdapter { bot ->
            prefs.edit()
                .putString(Prefs.PYLON_BOT_ID, bot.id)
                .putString(Prefs.PYLON_BOT_NAME, bot.name)
                .apply()
            startActivity(Intent(this, PylonControlActivity::class.java))
        }
        recycler.adapter = adapter

        swipeRefresh = findViewById(R.id.swipeRefresh)
        swipeRefresh.setColorSchemeResources(R.color.pylon_brand)
        emptyText = findViewById(R.id.emptyText)
        errorState = findViewById(R.id.errorState)
        errorStateText = findViewById(R.id.errorStateText)

        findViewById<Button>(R.id.retryLoadButton).setOnClickListener { load(showSpinner = true) }
        swipeRefresh.setOnRefreshListener { load(showSpinner = true) }

        findViewById<TextInputEditText>(R.id.searchInput).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                currentQuery = s?.toString()?.trim().orEmpty()
                applyFilter()
            }
        })

        load(showSpinner = true)
    }

    override fun onResume() {
        super.onResume()
        autoRefreshActive = true
        mainHandler.postDelayed(autoRefreshRunnable, 8000)
    }

    override fun onPause() {
        super.onPause()
        autoRefreshActive = false
        mainHandler.removeCallbacks(autoRefreshRunnable)
    }

    private fun load(showSpinner: Boolean) {
        if (isFinishing || isDestroyed) return
        if (showSpinner) swipeRefresh.isRefreshing = true
        api.getBots(token) { result ->
            if (isFinishing || isDestroyed) return@getBots
            runOnUiThread {
                swipeRefresh.isRefreshing = false
                result.onSuccess { bots ->
                    errorState.visibility = View.GONE
                    allBots = bots
                    applyFilter()
                }.onFailure {
                    if (allBots.isEmpty()) {
                        errorState.visibility = View.VISIBLE
                        emptyText.visibility = View.GONE
                        errorStateText.text = "Không tải được danh sách bot: ${it.message}"
                    } else if (showSpinner) {
                        Toast.makeText(this, "Lỗi tải danh sách bot: ${it.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun applyFilter() {
        val filtered = if (currentQuery.isEmpty()) {
            allBots
        } else {
            allBots.filter { it.name.contains(currentQuery, ignoreCase = true) }
        }
        adapter.submitBots(filtered)
        emptyText.visibility = if (allBots.isNotEmpty() && filtered.isEmpty()) {
            emptyText.text = "Không tìm thấy bot nào khớp \"$currentQuery\""
            View.VISIBLE
        } else if (allBots.isEmpty() && errorState.visibility != View.VISIBLE) {
            emptyText.text = "Chưa có bot nào trên panel này"
            View.VISIBLE
        } else {
            View.GONE
        }
    }
}

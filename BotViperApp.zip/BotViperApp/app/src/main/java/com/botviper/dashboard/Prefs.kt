package com.botviper.dashboard

/**
 * Central place for SharedPreferences keys so the whole app stays in sync.
 */
object Prefs {
    const val NAME = "bot_viper_prefs"
    const val SERVER_URL = "server_url"

    // Pterodactyl-style panel (PYLON)
    const val PYLON_PANEL_URL = "pylon_panel_url"   // e.g. http://192.168.1.5:3000
    const val PYLON_TOKEN = "pylon_token"           // JWT from /api/auth/login
    const val PYLON_USERNAME = "pylon_username"
    const val PYLON_BOT_ID = "pylon_bot_id"         // which bot on the panel to control
    const val PYLON_BOT_NAME = "pylon_bot_name"
}

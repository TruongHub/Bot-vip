package com.botviper.dashboard

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Main shell of the app: one WebView that displays the bot_viper Flask
 * dashboard, wrapped in native chrome (toolbar, bottom navigation,
 * pull-to-refresh, offline screen) so it feels like a real app instead
 * of "just a browser".
 *
 * Login is handled by the dashboard itself (Flask session + cookie) -
 * the WebView's CookieManager keeps the session alive between launches.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var offlineView: View
    private lateinit var toolbar: Toolbar

    private lateinit var baseUrl: String

    // Section paths served by dashboard.py -> matched to bottom_nav_menu.xml ids
    private val sectionPaths = mapOf(
        R.id.nav_home to "/",
        R.id.nav_music to "/music",
        R.id.nav_antispam to "/antispam",
        R.id.nav_leveling to "/leveling",
        R.id.nav_ai to "/ai",
        R.id.nav_config to "/config"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val savedUrl = prefs.getString(Prefs.SERVER_URL, null)
        if (savedUrl.isNullOrBlank()) {
            // Safety net: shouldn't normally happen since Splash routes correctly.
            startActivity(Intent(this, ServerSetupActivity::class.java))
            finish()
            return
        }
        baseUrl = savedUrl

        toolbar = findViewById(R.id.toolbar)
        toolbar.title = getString(R.string.app_name)
        setSupportActionBar(toolbar)

        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)
        offlineView = findViewById(R.id.offlineView)

        setupWebView()

        swipeRefresh.setOnRefreshListener { webView.reload() }
        swipeRefresh.setColorSchemeResources(R.color.green_primary)

        findViewById<Button>(R.id.retryButton).setOnClickListener {
            offlineView.visibility = View.GONE
            webView.loadUrl(baseUrl + "/")
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            val path = sectionPaths[item.itemId] ?: "/"
            offlineView.visibility = View.GONE
            webView.loadUrl(baseUrl + path)
            true
        }

        webView.loadUrl(baseUrl + "/")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                // Keep navigation to our own dashboard inside the WebView.
                // Compare host+port (authority) rather than a raw string
                // prefix of baseUrl: a plain prefix check breaks on the very
                // first server-side redirect that doesn't happen to repeat
                // baseUrl byte-for-byte (e.g. Flask redirecting to /login,
                // or a reverse proxy normalizing the URL) and would wrongly
                // kick the user out to a real browser, looking like the app
                // "can't connect" even though the dashboard answered fine.
                val requestUri = request.url
                val baseUri = android.net.Uri.parse(baseUrl)
                val sameHost = requestUri.host.equals(baseUri.host, ignoreCase = true)
                val basePort = if (baseUri.port != -1) baseUri.port else defaultPortFor(baseUri.scheme)
                val reqPort = if (requestUri.port != -1) requestUri.port else defaultPortFor(requestUri.scheme)
                return if (sameHost && basePort == reqPort) {
                    false
                } else {
                    // External link (e.g. docs, GitHub) - hand off to a real browser.
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    true
                }
            }

            private fun defaultPortFor(scheme: String?): Int = when (scheme) {
                "https" -> 443
                "http" -> 80
                else -> -1
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false
                offlineView.visibility = View.GONE
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    offlineView.visibility = View.VISIBLE
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_server_control -> {
                openPylonControl()
                true
            }
            R.id.action_refresh -> {
                webView.reload()
                true
            }
            R.id.action_change_server -> {
                startActivity(Intent(this, ServerSetupActivity::class.java))
                true
            }
            R.id.action_logout -> {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                webView.loadUrl(baseUrl + "/login")
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    private fun openPylonControl() {
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val hasSession = !prefs.getString(Prefs.PYLON_TOKEN, null).isNullOrBlank()
        val hasBot = !prefs.getString(Prefs.PYLON_BOT_ID, null).isNullOrBlank()
        val target = when {
            hasSession && hasBot -> PylonControlActivity::class.java
            hasSession -> PylonBotListActivity::class.java
            else -> PylonLoginActivity::class.java
        }
        startActivity(Intent(this, target))
    }
}

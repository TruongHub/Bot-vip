package com.botviper.dashboard

import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

enum class SocketState { CONNECTING, CONNECTED, DISCONNECTED }

/**
 * Tails the real log stream from server/ws.js. That server sends raw text
 * chunks (not JSON-wrapped events) straight from the bot's stdout/stderr,
 * piped through runner.js's streamLogs(). A chunk can contain multiple
 * lines, so we forward it as-is and let the UI append it.
 *
 * This version owns a single long-lived OkHttpClient and reconnects itself
 * with a capped exponential backoff, instead of the caller creating a brand
 * new client/socket pair on every retry (which used to leak a thread pool
 * per attempt and made the console flaky on bad Wi-Fi).
 */
class PylonLogSocket(
    private val socketUrl: String,
    private val onChunk: (String) -> Unit,
    private val onStateChange: (SocketState) -> Unit
) {
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val mainHandler = Handler(Looper.getMainLooper())
    private var webSocket: WebSocket? = null
    private var wantsConnection = false
    private var retryAttempt = 0
    private var reconnectScheduled = false

    fun connect() {
        wantsConnection = true
        retryAttempt = 0
        openSocket()
    }

    private fun openSocket() {
        if (!wantsConnection) return
        reconnectScheduled = false
        mainHandler.post { onStateChange(SocketState.CONNECTING) }

        val request = Request.Builder().url(socketUrl).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                retryAttempt = 0
                mainHandler.post { onStateChange(SocketState.CONNECTED) }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                mainHandler.post { onChunk(text) }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                mainHandler.post { onStateChange(SocketState.DISCONNECTED) }
                scheduleReconnect()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                mainHandler.post { onStateChange(SocketState.DISCONNECTED) }
                scheduleReconnect()
            }
        })
    }

    private fun scheduleReconnect() {
        if (!wantsConnection || reconnectScheduled) return
        reconnectScheduled = true
        // Capped exponential backoff: 2s, 4s, 8s, ... up to 20s.
        val delayMs = (2000L * (1 shl retryAttempt.coerceAtMost(3))).coerceAtMost(20000L)
        retryAttempt++
        mainHandler.postDelayed({ openSocket() }, delayMs)
    }

    fun disconnect() {
        wantsConnection = false
        mainHandler.removeCallbacksAndMessages(null)
        webSocket?.close(1000, "closing")
        webSocket = null
    }
}

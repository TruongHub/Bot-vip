package com.botviper.dashboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

/**
 * Real control screen for one bot on the PYLON panel. Every button here
 * calls the actual Express routes in server/bots.js, which spawn/kill a
 * real child process via runner.js on the Termux host — this works even
 * if the bot process itself has crashed, because PYLON runs as its own
 * independent supervisor process.
 *
 * Adds: Kill (force stop), live CPU/RAM/uptime stats, a capped/colorized
 * console buffer so it can't grow forever, an auto-scroll toggle, copy/clear
 * console actions, and a command input to send a line straight to the bot's
 * stdin (POST /api/bots/{id}/command — see SERVER_API_NOTES.md).
 */
class PylonControlActivity : AppCompatActivity() {

    private lateinit var api: PylonApi
    private lateinit var token: String
    private lateinit var botId: String
    private var logSocket: PylonLogSocket? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pollingActive = false
    private var actionPending = false
    private var autoScroll = true

    private lateinit var statusValue: TextView
    private lateinit var cpuValue: TextView
    private lateinit var ramValue: TextView
    private lateinit var uptimeValue: TextView
    private lateinit var consoleText: TextView
    private lateinit var consoleScroll: ScrollView
    private lateinit var consoleConnDot: android.view.View
    private lateinit var consoleConnLabel: TextView
    private lateinit var autoScrollToggle: TextView
    private lateinit var commandInput: EditText
    private lateinit var powerButtons: List<Button>

    private val consoleLines = ArrayDeque<CharSequence>()

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!pollingActive) return
            refreshStatus()
            mainHandler.postDelayed(this, 5000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pylon_control)

        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val panelUrl = prefs.getString(Prefs.PYLON_PANEL_URL, null)
        val savedToken = prefs.getString(Prefs.PYLON_TOKEN, null)
        val savedBotId = prefs.getString(Prefs.PYLON_BOT_ID, null)
        val botName = prefs.getString(Prefs.PYLON_BOT_NAME, "Bot")

        if (panelUrl.isNullOrBlank() || savedToken.isNullOrBlank() || savedBotId.isNullOrBlank()) {
            startActivity(Intent(this, PylonLoginActivity::class.java))
            finish()
            return
        }
        api = PylonApi(panelUrl)
        token = savedToken
        botId = savedBotId

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = botName
        setSupportActionBar(toolbar)

        statusValue = findViewById(R.id.statusValue)
        cpuValue = findViewById(R.id.cpuValue)
        ramValue = findViewById(R.id.ramValue)
        uptimeValue = findViewById(R.id.uptimeValue)
        consoleText = findViewById(R.id.consoleText)
        consoleScroll = findViewById(R.id.consoleScroll)
        consoleConnDot = findViewById(R.id.consoleConnDot)
        consoleConnLabel = findViewById(R.id.consoleConnLabel)
        autoScrollToggle = findViewById(R.id.autoScrollToggle)
        commandInput = findViewById(R.id.commandInput)

        val startButton = findViewById<Button>(R.id.startButton)
        val restartButton = findViewById<Button>(R.id.restartButton)
        val stopButton = findViewById<Button>(R.id.stopButton)
        val killButton = findViewById<Button>(R.id.killButton)
        powerButtons = listOf(startButton, restartButton, stopButton, killButton)

        startButton.setOnClickListener { confirmPower("start", danger = false) }
        restartButton.setOnClickListener { confirmPower("restart", danger = false) }
        stopButton.setOnClickListener { confirmPower("stop", danger = true) }
        killButton.setOnClickListener { confirmPower("kill", danger = true) }

        setConnLabel(SocketState.CONNECTING)

        autoScrollToggle.setOnClickListener {
            autoScroll = !autoScroll
            autoScrollToggle.text = if (autoScroll) "Auto-scroll: ON" else "Auto-scroll: OFF"
            if (autoScroll) scrollConsoleToBottom()
        }

        findViewById<TextView>(R.id.clearLogsButton).setOnClickListener {
            consoleLines.clear()
            consoleText.text = ""
        }

        findViewById<TextView>(R.id.copyLogsButton).setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("console", consoleText.text.toString()))
            Toast.makeText(this, "Đã copy console", Toast.LENGTH_SHORT).show()
        }

        findViewById<ImageButton>(R.id.sendCommandButton).setOnClickListener { sendTypedCommand() }
        commandInput.setOnEditorActionListener { _, actionId, event ->
            val isSend = actionId == EditorInfo.IME_ACTION_SEND ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            if (isSend) {
                sendTypedCommand()
                true
            } else {
                false
            }
        }

        loadLogSnapshot()
        connectLiveLogs()
    }

    override fun onResume() {
        super.onResume()
        pollingActive = true
        mainHandler.post(pollRunnable)
    }

    override fun onPause() {
        super.onPause()
        pollingActive = false
        mainHandler.removeCallbacks(pollRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        logSocket?.disconnect()
        mainHandler.removeCallbacksAndMessages(null)
    }

    private fun setButtonsEnabled(enabled: Boolean) {
        powerButtons.forEach { it.isEnabled = enabled }
    }

    private fun confirmPower(action: String, danger: Boolean) {
        val label = action.replaceFirstChar { it.uppercase() }
        val message = if (danger) {
            "Xác nhận $label bot này? Lệnh sẽ gửi thật tới panel trên Termux, có thể ngắt bot ngay lập tức."
        } else {
            "Xác nhận $label bot này? Lệnh sẽ gửi thật tới panel trên Termux."
        }
        android.app.AlertDialog.Builder(this)
            .setTitle(label)
            .setMessage(message)
            .setPositiveButton("Đồng ý") { _, _ -> sendPower(action) }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun sendPower(action: String) {
        if (actionPending) return
        actionPending = true
        setButtonsEnabled(false)
        api.power(token, botId, action) { result ->
            if (isFinishing || isDestroyed) return@power
            runOnUiThread {
                actionPending = false
                setButtonsEnabled(true)
                result.onSuccess {
                    Toast.makeText(this, "Đã gửi lệnh: $action", Toast.LENGTH_SHORT).show()
                    refreshStatus()
                }.onFailure {
                    Toast.makeText(this, "Lỗi: ${it.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun sendTypedCommand() {
        val text = commandInput.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return
        appendConsole("> $text\n")
        commandInput.setText("")
        api.sendCommand(token, botId, text) { result ->
            if (isFinishing || isDestroyed) return@sendCommand
            runOnUiThread {
                result.onFailure {
                    Toast.makeText(this, "Không gửi được lệnh: ${it.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun refreshStatus() {
        api.getBots(token) { result ->
            if (isFinishing || isDestroyed) return@getBots
            runOnUiThread {
                result.onSuccess { bots ->
                    val bot = bots.find { it.id == botId } ?: return@onSuccess
                    statusValue.text = bot.status.replaceFirstChar { it.uppercase() }
                    statusValue.setTextColor(statusColor(bot.status))

                    cpuValue.text = if (bot.cpuPercent >= 0) "${"%.0f".format(bot.cpuPercent)}%" else "—"

                    ramValue.text = when {
                        bot.ramUsedMb >= 0 && bot.ramLimitMb > 0 -> "${bot.ramUsedMb}/${bot.ramLimitMb}MB"
                        bot.ramMb > 0 -> "${bot.ramMb}MB"
                        else -> "—"
                    }

                    uptimeValue.text = if (bot.uptimeSec >= 0) formatUptime(bot.uptimeSec) else "—"
                }
            }
        }
    }

    private fun statusColor(status: String): Int {
        val res = when (status) {
            "running" -> R.color.pylon_success
            "building", "starting" -> R.color.pylon_warning
            "error", "crashed" -> R.color.pylon_danger
            else -> R.color.pylon_muted
        }
        return getColor(res)
    }

    private fun formatUptime(totalSeconds: Long): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return if (h > 0) "%dh%02dm".format(h, m) else "%dm%02ds".format(m, s)
    }

    private fun setConnLabel(state: SocketState) {
        val (colorRes, text) = when (state) {
            SocketState.CONNECTING -> R.color.pylon_warning to "Console — đang kết nối..."
            SocketState.CONNECTED -> R.color.pylon_success to "Console — trực tiếp từ Termux"
            SocketState.DISCONNECTED -> R.color.pylon_danger to "Console — mất kết nối, đang thử lại..."
        }
        val color = getColor(colorRes)
        consoleConnDot.background.setColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN)
        consoleConnLabel.text = text
        consoleConnLabel.setTextColor(color)
    }

    private fun loadLogSnapshot() {
        api.getLogsSnapshot(token, botId) { result ->
            if (isFinishing || isDestroyed) return@getLogsSnapshot
            runOnUiThread {
                result.onSuccess { logs -> appendConsole(logs) }
            }
        }
    }

    private fun connectLiveLogs() {
        val url = api.buildLogsSocketUrl(token, botId)
        logSocket = PylonLogSocket(
            socketUrl = url,
            onChunk = { chunk -> appendConsole(chunk) },
            onStateChange = { state ->
                if (!isFinishing && !isDestroyed) setConnLabel(state)
            }
        )
        logSocket?.connect()
    }

    /** Colorize a console line by simple heuristics — typed commands cyan, error lines red, warnings yellow, rest green. */
    private fun colorForLine(line: String): Int {
        val lower = line.lowercase()
        return when {
            line.startsWith("> ") -> R.color.pylon_console_info
            "error" in lower || "exception" in lower || "fatal" in lower -> R.color.pylon_console_error
            "warn" in lower -> R.color.pylon_console_warn
            else -> R.color.pylon_console_text
        }
    }

    private fun appendConsole(text: String) {
        if (text.isEmpty()) return
        mainHandler.post {
            val lines = text.split("\n")
            for ((idx, line) in lines.withIndex()) {
                if (line.isEmpty() && idx == lines.lastIndex) continue
                consoleLines.addLast(line)
                // Cap the buffer so a noisy bot can't grow the console into an OOM/ANR.
                while (consoleLines.size > MAX_CONSOLE_LINES) consoleLines.removeFirst()
            }
            renderConsole()
            if (autoScroll) scrollConsoleToBottom()
        }
    }

    private fun renderConsole() {
        val builder = SpannableStringBuilder()
        for (line in consoleLines) {
            val start = builder.length
            builder.append(line).append("\n")
            val colorRes = colorForLine(line.toString())
            builder.setSpan(
                ForegroundColorSpan(getColor(colorRes)),
                start,
                builder.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        consoleText.text = builder
    }

    private fun scrollConsoleToBottom() {
        consoleScroll.post { consoleScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    companion object {
        private const val MAX_CONSOLE_LINES = 1500
    }
}

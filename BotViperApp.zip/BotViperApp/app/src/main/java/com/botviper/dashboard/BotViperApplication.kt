package com.botviper.dashboard

import android.app.Application
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Catches any uncaught crash, writes the full Kotlin/Java stack trace plus
 * basic device info to a plain-text file under this app's external files
 * folder, then hands off to the default system handler so the normal
 * "keeps stopping" dialog still appears as before.
 *
 * The file is readable with any file manager (e.g. ZArchiver) at:
 *   Android/data/com.botviper.dashboard/files/crash_log.txt
 * No root, ADB, or PC required to retrieve it.
 */
class BotViperApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                writeCrashLog(throwable)
            } catch (ignored: Exception) {
                // Never let logging itself block the crash from surfacing normally.
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun writeCrashLog(throwable: Throwable) {
        val dir = getExternalFilesDir(null) ?: filesDir
        val file = File(dir, "crash_log.txt")

        val sw = StringWriter()
        throwable.printStackTrace(PrintWriter(sw))

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val header = buildString {
            appendLine("===== Bot Viper crash =====")
            appendLine("Time: $timestamp")
            appendLine("App version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            appendLine()
        }

        // Keep only the most recent crash so the file never grows unbounded.
        file.writeText(header + sw.toString())
    }
}

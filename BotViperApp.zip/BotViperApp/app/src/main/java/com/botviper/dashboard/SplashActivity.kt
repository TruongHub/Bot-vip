package com.botviper.dashboard

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

/**
 * Splash screen shown briefly on launch.
 * Decides whether to go straight to the dashboard (server URL already saved)
 * or ask the user to enter their dashboard address first.
 */
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({
            val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
            val savedUrl = prefs.getString(Prefs.SERVER_URL, null)

            val next = if (savedUrl.isNullOrBlank()) {
                Intent(this, ServerSetupActivity::class.java)
            } else {
                Intent(this, MainActivity::class.java)
            }
            startActivity(next)
            finish()
        }, 900)
    }
}

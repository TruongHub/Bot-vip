package com.botviper.dashboard

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/**
 * First-run (or "Đổi server") screen where the user types in the address
 * where their dashboard.py Flask app is reachable, e.g.:
 *   http://192.168.1.5:5000        (Termux on local LAN)
 *   https://my-domain.example.com  (if reverse-proxied / public, incl. a
 *                                    Pterodactyl-style panel domain)
 *
 * Before saving, the app now actually probes the address (short-timeout
 * GET) so a wrong IP/port or a Termux session that isn't running yet is
 * caught right here with a clear message, instead of silently saving and
 * only failing later inside the WebView.
 */
class ServerSetupActivity : AppCompatActivity() {

    private val probeClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_server_setup)

        val urlInputLayout = findViewById<TextInputLayout>(R.id.urlInputLayout)
        val urlInput = findViewById<TextInputEditText>(R.id.urlInput)
        val connectButton = findViewById<Button>(R.id.connectButton)
        val progress = findViewById<ProgressBar>(R.id.setupProgress)

        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        prefs.getString(Prefs.SERVER_URL, null)?.let { urlInput.setText(it) }

        connectButton.setOnClickListener {
            val raw = urlInput.text?.toString()?.trim().orEmpty()

            if (raw.isEmpty()) {
                urlInputLayout.error = getString(R.string.error_empty_url)
                return@setOnClickListener
            }

            var url = raw
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                // Be forgiving: assume http:// for a plain IP:port like a Termux LAN address
                url = "http://$url"
            }
            if (!isLikelyValidUrl(url)) {
                urlInputLayout.error = getString(R.string.error_invalid_url)
                return@setOnClickListener
            }
            urlInputLayout.error = null

            // Strip a trailing slash so path concatenation elsewhere stays clean
            val normalized = url.trimEnd('/')

            connectButton.isEnabled = false
            connectButton.text = getString(R.string.btn_testing)
            progress.visibility = View.VISIBLE

            testConnection(normalized) { error ->
                connectButton.isEnabled = true
                connectButton.text = getString(R.string.btn_connect)
                progress.visibility = View.GONE

                if (error == null) {
                    prefs.edit().putString(Prefs.SERVER_URL, normalized).apply()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    urlInputLayout.error = error
                }
            }
        }
    }

    /**
     * Probes [url] with a short-timeout GET on a background thread and
     * reports back on the main thread. Any HTTP response (even 404/401/500)
     * means the host answered, so it's treated as "reachable" — only a
     * network-level failure (timeout, refused, unknown host) is an error,
     * since the dashboard's actual routes/auth are none of this check's
     * business.
     */
    private fun testConnection(url: String, onResult: (errorMessage: String?) -> Unit) {
        Thread {
            val error: String? = try {
                val req = Request.Builder().url("$url/").get().build()
                probeClient.newCall(req).execute().use { null }
            } catch (e: SocketTimeoutException) {
                getString(R.string.error_unreachable_timeout)
            } catch (e: UnknownHostException) {
                getString(R.string.error_unreachable_host)
            } catch (e: IOException) {
                val msg = e.message.orEmpty()
                if ("ECONNREFUSED" in msg || "refused" in msg.lowercase()) {
                    getString(R.string.error_unreachable_refused)
                } else {
                    getString(R.string.error_unreachable_generic, msg)
                }
            } catch (e: Exception) {
                getString(R.string.error_unreachable_generic, e.message ?: e.toString())
            }
            mainHandler.post { onResult(error) }
        }.start()
    }

    private fun isLikelyValidUrl(url: String): Boolean {
        return try {
            val u = java.net.URL(url)
            !u.host.isNullOrBlank()
        } catch (e: Exception) {
            false
        }
    }
}

# Bot Viper — App Android riêng cho dashboard

App này **không** viết lại dashboard, mà bọc dashboard Flask (`dashboard.py`) hiện có
của bạn vào trong 1 app Android thật: có splash screen, thanh điều hướng dưới (bottom nav),
toolbar riêng, kéo để làm mới, và màn hình báo lỗi khi mất kết nối — thay vì mở trình duyệt.

## Cách build ra APK

1. Mở Android Studio (hoặc đưa cả thư mục `BotViperApp/` này cho ChatGPT/AI khác để build hộ).
2. `File → Open` → chọn thư mục `BotViperApp`.
3. Đợi Gradle sync xong (lần đầu cần mạng để tải Gradle + thư viện).
4. `Build → Build Bundle(s) / APK(s) → Build APK(s)`.
5. APK nằm ở `app/build/outputs/apk/debug/app-debug.apk`.

## Trước khi dùng: chạy dashboard sao cho điện thoại vào được

Trong `dashboard.py`, server nghe ở `0.0.0.0:8080` theo mặc định (đổi được qua biến
môi trường `DASHBOARD_HOST` / `DASHBOARD_PORT` trong `.env`). Điện thoại và máy chạy
Termux **phải cùng mạng Wi-Fi (LAN)**, hoặc bạn cần một domain/public URL nếu deploy
lên Pterodactyl/VPS.

- Tìm IP máy chạy Termux: `ifconfig` hoặc `ip addr` → tìm dòng `inet 192.168.x.x`
- Mở app → nhập `http://192.168.x.x:8080` vào màn hình "Kết nối Dashboard"

Nếu deploy public (Pterodactyl/VPS có domain), nhập thẳng `https://domain-cua-ban.com`.

## Vì sao chọn hướng WebView thay vì viết lại 100% native?

`dashboard.py` hiện tại render HTML phía server (Flask/Jinja) và đăng nhập bằng session
cookie — không có API JSON riêng. Viết lại native hoàn toàn nghĩa là phải tách logic đó
ra API JSON trước (tốn nhiều công), trong khi WebView cho kết quả giống hệt giao diện
bạn đã làm (theme Minecraft-server) mà không cần đụng vào `dashboard.py`.

Nếu sau này bạn muốn nâng cấp lên native thật (mượt hơn, có thể làm widget ngoài màn hình,
push notification khi có sự kiện...), bước tiếp theo là thêm vài route trả JSON
(vd: `/api/status`) vào `dashboard.py` — mình có thể giúp viết phần đó bất cứ lúc nào.

## Điều khiển bot thật qua PYLON Panel (Start/Stop/Restart + Console)

Trước tiên chạy panel trên Termux: `cd pylon-panel-termux && npm install && npm start`
(mặc định nghe cổng 3000). Vào app → menu toolbar → "Điều khiển bot (PYLON)":

1. **Đăng nhập lần đầu**: nhập địa chỉ panel (vd `http://192.168.1.5:3000`, IP máy Termux
   trong cùng mạng LAN), username/password đã tạo trên panel (hoặc đăng ký qua `/api/auth/register`
   nếu chưa có tài khoản — hiện app chỉ hỗ trợ đăng nhập, có thể đăng ký tạm qua trình duyệt).
2. **Chọn bot**: app tải danh sách bot thật từ panel, bấm vào bot muốn điều khiển.
3. **Màn điều khiển**: Start/Stop/Restart gọi thẳng `POST /api/bots/:id/start|stop|restart`
   — đây là lệnh thật gửi tới `runner.js`, spawn/kill process con thật trên Termux, **chạy
   được kể cả khi bot đang crash hoặc chưa từng chạy**, vì PYLON là 1 tiến trình Node.js
   độc lập, không nằm chung process với bot (khác với `dashboard.py` trước đây).
4. **Console**: tải sẵn log gần nhất qua `GET /api/bots/:id/logs`, sau đó mở WebSocket thật
   tới `/ws/logs` để nhận log trực tiếp — y hệt log bạn thấy khi chạy `tmux attach`.

Giao diện màn đăng nhập/danh sách bot/điều khiển dùng tông màu tím-trắng giống bản gốc
PYLON (`--brand:#6C4CFF`), tách biệt với theme xanh-vàng của phần dashboard Flask.

⚠️ Token đăng nhập (JWT) lưu trong SharedPreferences trên máy — hết hạn sau 7 ngày
(theo cấu hình `JWT_SECRET`/`expiresIn` trong `auth.js`), lúc đó app sẽ tự đưa bạn về
màn đăng nhập lại.

### Bản cập nhật: quản lý đầy đủ hơn, giống Pterodactyl thật

- **4 nút điều khiển**: Start / Restart / Stop / **Kill** (dừng cứng khi bot treo).
- **Thẻ số liệu**: Trạng thái, CPU, RAM, Uptime — tự cập nhật mỗi 5 giây (bot list
  cũng tự làm mới mỗi 8 giây, có ô tìm kiếm theo tên bot).
- **Console giống terminal thật**: tô màu theo dòng log (đỏ = error, vàng = warn),
  giới hạn 1500 dòng gần nhất để không bao giờ bị đơ/tràn bộ nhớ dù bot log liên tục,
  nút Auto-scroll / Copy / Clear, và **ô gõ lệnh gửi thẳng vào bot** (như gõ lệnh
  trong `tmux attach`).
- **Kết nối ổn định hơn**: WebSocket console tự kết nối lại (backoff tăng dần 2s→20s)
  khi mất mạng, có chấm trạng thái xanh/vàng/đỏ để biết đang live hay đang retry.
- 3 tính năng mới (Kill, gõ lệnh, số liệu CPU/RAM/Uptime) cần thêm route tương ứng
  trong panel Node.js — chi tiết ở [`SERVER_API_NOTES.md`](./SERVER_API_NOTES.md).
  Nếu panel chưa có route đó, app vẫn chạy bình thường, chỉ báo lỗi nhẹ (Toast) hoặc
  hiện "—" ở ô số liệu thay vì crash.

## Bảo mật

- File `.env` gốc của bạn có `DASHBOARD_SECRET_KEY` / mật khẩu — **đừng** đưa file đó
  cho ai build hộ APK. Chỉ cần đưa thư mục `BotViperApp/` này (không chứa bí mật gì).
- App đang cho phép cleartext traffic (HTTP thường, không HTTPS) để tiện dùng trong LAN.
  Nếu public ra internet, nên đổi dashboard sang HTTPS (vd qua Cloudflare Tunnel/Nginx)
  rồi tắt `usesCleartextTraffic` trong `AndroidManifest.xml`.
